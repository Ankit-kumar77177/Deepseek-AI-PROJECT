import OpenAI from "openai";
import { Promt } from "../model/promt.model.js";

// code from open router ka api ka hai
 const openai = new OpenAI({
  baseURL: "https://openrouter.ai/api/v1",
  apiKey: process.env.OPENAI_API_KEY,
});
//yahan tak
console.log(openai.apiKey);

export const sendPromt=async(req, res)=>{
  const { content }=req.body;
  const userId=req.userId;

  if(!content || content.trim() === "") {
    return res.status(400).json({ error:" Prompt content is required" })
  }
  try{
    // save user prompt
    const userPromt=await Promt.create({
       userId,
      role:"user",
      content
    })

    // send to openAI(from API code ) copy from api code
    const completion = await openai.chat.completions.create({
      model: "deepseek/deepseek-r1:free", // free model on OpenRouter
      messages: [
        { role: "user", content:content }
      ],
      extra_headers: {
        "HTTP-Referer": "http://localhost:3000", // optional
        "X-Title": "My Node App",                // optional
      },
    });
    
     
    const aiContent=completion.choices[0].message.content

  // save assistant prompt
  const aiMessage=await Promt.create({
    userId,
    role:"assistant",
    content:aiContent
    })
    return res.status(200).json({replay:aiContent})

  }catch (error){
    console.error("Error in Prompt",error)  
    return res.status(500).json({ error: "Something went wrong with the Ai Promt" })
  }
};
